#include<bits/stdc++.h>
using namespace std;
int main()
{

     int x,y;

     cin>>x>>y;

    cout<<x<<" + "<<y<<" = "<<x+y<<endl;
    cout<<x<<" * "<<y<<" = "<<(long long)x*y<<endl;
    cout<<x<<" - "<<y<<" = "<<x-y<<endl;



    return 0;
}