#include<iostream>
using namespace std;
int main()
{
    int x;
    cin>>x;

    cout<<(char)x<<endl;

    // char c;
    // cin>>c;

    // cout<<(int)c<<endl;   //typecasting

    // double d;
    // cin>>d;
    // cout<<d<<endl;

    // int ascii=c;

    // cout<<ascii<<endl;



    return 0;
}