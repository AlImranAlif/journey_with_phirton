#include<bits/stdc++.h>
using namespace std;
int main()
{

     char name[100]="Rahim Hossain";  //only first line accept 



    return 0;
}