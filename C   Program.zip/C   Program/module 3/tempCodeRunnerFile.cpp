 for(int i=0,j=strlen(s);i<=j;i++,j--)
    //  {
    //     if(s[i]>s[j])
    //     {
    //         swap(s[i],s[j]);
    //     }
    //  }