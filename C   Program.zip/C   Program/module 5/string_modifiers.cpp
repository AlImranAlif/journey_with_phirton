#include<bits/stdc++.h>
using namespace std;
int main()
{  
/*
     string s1 = "Hello World.";
     string s2=" Hello,";
     //s1+=s2;    //normally add another string

     s1.append(s2);   //using append function

     int x=10;
     int y=20;
     x+=y;

     cout<<s1<<endl;

     string s3="Hello ";
     s3.push_back('A');  //only character /single character
     // s3+='B';  //alternative of push_back() 
     cout<<s3<<endl;


     string s4="Hello";
     s4[0]='U';
     cout<<s4<<endl;


     string s5="Hello";
     s5.pop_back();
     s5.pop_back();
     cout<<s5<<endl;


*/   
    string s6="Hello World";

   // s6.replace(6,0,"Bangladesh ");
   s6.insert(5," Pias");

   // s6.erase(5,1);

   // string s7="Hi";
   // s6="Gello";
   cout<<s6<<endl;
   // s7.assign(s6);
  //  s7.assign("Chagol");
  //  cout<<s7<<endl;

    


        






    return 0;
}