#include<bits/stdc++.h>
using namespace std;
int main()
{

    string s;
    cin>>s;
    int n=s.size();
    for(int i=0;i<n-5;i++)
    {
        for(int j=i+1;j<n-4;j++)
        {
            for(int k=j+1;)
        }
    }


    return 0;
}