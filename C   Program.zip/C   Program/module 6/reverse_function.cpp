#include<bits/stdc++.h>
using namespace std;
int main()
{

    //  int n;
    //  cin>>n;
    //  int a[n];
    //  for(int i=0;i<n;i++)
    //  {
    //     cin>>a[i];
    //  }

    //  //sort();
    //  reverse(a,a+n);   //reverse(starting,ending);
    //  for(int i=0;i<n;i++)
    //  {
    //     cout<<a[i]<<" ";
    //  }

    string s;
    cin>>s;
    reverse(s.begin(),s.end());
    cout<<s;




    return 0;
}