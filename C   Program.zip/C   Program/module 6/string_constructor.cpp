#include<bits/stdc++.h>
using namespace std;
int main()
{

    //string s="Hello";
    //1
    // string s("Hello");
    //2
    string s("Hello World",4);
    //3
    //string s="Hello World";
    //string t(s,2);
    //4
    //string s(5,'A');
    cout<<s<<endl;



    return 0;
}