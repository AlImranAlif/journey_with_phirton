#include<iostream>
int main()
{

   // std::cout<<"Hello world!";

    int x=200;
    char c='A';
    double d=34.65;
    std::cout<<x<<" nije theke print korte char "<<c<<" "<<std::endl; 
    std::cout<<d;


    return 0;
}