#include<iostream>
#include<iomanip>  //for set precision function
using namespace std;
int main()
{
    double d=23.45676;
    cout<<fixed<<setprecision(20)<<d<<endl;




    return 0;
}