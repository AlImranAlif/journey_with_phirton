#include<iostream>
using namespace std;
int main()
{
    int x=19;
    // (condition)? T : F ;
    (x%2==0)?cout<<"Even":cout<<"Odd";





    return 0;
}