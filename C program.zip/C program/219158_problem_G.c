#include<stdio.h>
int main()
{
    long long n;
    scanf("%lld",&n);
    long long sum=0;

    sum=((n+1)*n)/2;

    printf("%lld",sum);




    return 0;
}