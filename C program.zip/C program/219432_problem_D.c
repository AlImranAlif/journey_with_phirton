#include<stdio.h>
int main()
{
    int n;
    while(scanf("%d",&n)!=EOF)  // end of file
    {
        
        

        if(n==1999)
        {
            printf("Correct\n");
            break;
        }
        else
        {
            printf("Wrong\n");
        }
      


    }



    return 0;
}
//terminal
// linux -> ctrl + d
// windows -> ctrl + z
