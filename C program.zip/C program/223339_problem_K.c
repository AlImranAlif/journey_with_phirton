#include<stdio.h>
#include<limits.h>

int a[100000];

int max_value(int *p,int n,int i)
{
    

}

int main()
{
    int n;
    scanf("%d",&n);

   
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }

    

    return 0;
}