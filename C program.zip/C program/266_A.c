#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);

    char a[n+1];
    int r_c=0,g_c=0,b_c=0
    for(int i=0;i<n+1;i++)
    {
        if(a[i]=='R')
        {
            
        }
    }



    return 0;
}