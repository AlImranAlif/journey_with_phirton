#include<stdio.h>
int main()
{
    int x,y;
    scanf("%d%d",&x,&y);

    int z=x*y;

    printf("%d",z/2);




    return 0;
}