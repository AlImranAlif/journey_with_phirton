#include<stdio.h>

int main()
{
    int b,c ;
    short int a=7;
    char ch;

    int f;

    scanf("%d %d", &f,&a);

   

    printf("%08d\n",f);
    printf("%08d",a);




    return 0;
}