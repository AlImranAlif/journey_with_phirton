#include<stdio.h>

int main()
{
    int a = 5;


   

    if(a < 15)
    {
        a+=100;
        printf("Hello if\n");


    }


    printf("%d \n",a);

    

   



    return 0;
}