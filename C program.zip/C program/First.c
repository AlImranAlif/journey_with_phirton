/*
This is my first program
*/
/*
#include<stdio.h>   //linking section or header file

int main()
{
    printf("Hello C programming\n");     //printf();  built in function. collect print program from liniking section    "\n" mean line break
    printf("Hello world!");
    return 0;
}

*/

#include<stdio.h>

int main()
{
    int a;

    scanf("%d", &a);   //&a describe the a memory location

    printf("%d", a);



    return 0;
}
