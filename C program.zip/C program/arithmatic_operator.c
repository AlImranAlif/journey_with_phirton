#include<stdio.h>
int main()
{
 int a=100000,b=100000;

long long int result= 1LL*a*b;

printf("%lld", result);



    return 0;
}