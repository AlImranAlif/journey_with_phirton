#include<stdio.h>
#include<math.h>
int main()
{
    int a=5;

    a++;
    a+=1;



    printf("%d",a);





    return 0;
}
