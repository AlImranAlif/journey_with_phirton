// must practice using loop

#include<stdio.h>
#include<string.h>

int main()
{
    char a[20]="abc";
    char b[20]="ghi";



    // int len_a = strlen(a);
    // int len_b = strlen(b);

    int x = strcmp(a,b);

    printf("%d",x);
    
    




    return 0;
}