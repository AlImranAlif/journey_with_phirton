#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    
    int A;
    scanf("%d",&A);
    long long int B;
    scanf("%lld",&B);
    float C;
    scanf("%f",&C);
    char D;
    scanf("%c",&D);
    
        printf("%d\n",A);
        printf("%lld\n",B);
        printf("%f\n",C);
        printf("%c",D);
    
    
    return 0;
}
