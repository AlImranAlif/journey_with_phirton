#include<stdio.h>
#include<string.h>
int main()
{
    // char a[10]="def";

    // char b[10]="abcdef";

    // printf("%s %s\n",a,b);

    // int length=strlen(a);

    // for(int i=0;i<length;i++)
    // {
    //     a[i]=b[i];
    // }


    // printf("%s %s",a,b);


    //   printf("%d",length);

    

    // b  ->  a
    // strcpy(b, a);
    //  printf("%s %s",a,b);

    char a[15]="Hello";
    char b[15];

    strcpy(b,"Welcome");

    printf("%s",b);

    return 0;
}