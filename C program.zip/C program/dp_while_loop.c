#include<stdio.h>

int main()
{
    /*
        intialization;
        do{
        statement1;
        statement2;
        increment/decrement;
        }while(condition);
    
    
    */
   printf("Befor loop\n");

   int i = 00;

   do{
    printf("Inside do while loop\n");
    i++;
   }while(i<5);






    return 0;
}