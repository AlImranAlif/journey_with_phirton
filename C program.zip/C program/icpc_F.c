#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);

    for(int i=1;i<=t;i++)
    {
        printf("Ei Matha-Mota-Rogchota joddin achhe, non-profit diye kon ghaash ta katbo!\n");
    }
    return 0;
}