#include<stdio.h>

int main()
{
    // for(int i= 0;i<=10;i--)   //there is no increment. value is always become 0 ..and if there is decrement it also run in infinity time
    // {
    //     printf("Hello ");
    // }

    int i=0;
    while(i<10)
    {
        printf("Baal ");
        i--;
    }

    return 0;
}