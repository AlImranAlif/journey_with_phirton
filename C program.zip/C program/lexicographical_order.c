#include<stdio.h>
#include<string.h>

int main()
{
    




    return 0;
}