#include<stdio.h>

int main()
{
    char c;
    scanf("%c",&c);

    if(c=='a')
    {
        printf("b");
    }
    else if(c=='b')
    {
        printf("c");
    }
    else if(c=='c')
    {
        printf("d");
    }
    else if(c=='d')
    {
        printf("e");
    }
    else if(c=='e')
    {
        printf("f");
    }
    else if(c=='f')
    {
        printf("g");
    }
    else if(c=='g')
    {
        printf("h");
    }
    else if(c=='h')
    {
        printf("i");
    }
    else if(c=='i')
    {
        printf("j");
    }
    else if(c=='j')
    {
        printf("k");
    }
    else if(c=='k')
    {
        printf("l");
    }
    else if(c=='l')
    {
        printf("m");
    }
    else if(c=='m')
    {
        printf("n");
    }
    else if(c=='n')
    {
        printf("o");
    }
    else if(c=='o')
    {
        printf("p");
    }
    else if(c=='p')
    {
        printf("q");
    }
    else if(c=='q')
    {
        printf("r");
    }
    else if(c=='r')
    {
        printf("s");
    }
    else if(c=='s')
    {
        printf("t");
    }
    else if(c=='t')
    {
        printf("u");
    }
    else if(c=='u')
    {
        printf("v");
    }
    else if(c=='v')
    {
        printf("w");
    }
    else if(c=='w')
    {
        printf("x");
    }
    else if(c=='x')
    {
        printf("y");
    }
    else if(c=='y')
    {
        printf("z");
    }
    else if(c=='z')
    {
        printf("a");
    }





    return 0;
}