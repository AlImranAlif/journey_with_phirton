#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    
    for(int i=1;i<=t;i++)
    {
        int count=0;
        int n,k;
        scanf("%d %d",&n,&k);

    //     for(int j=1;j<=n;j++)
    // {
    //     int x,y;
    //     scanf("%d %d",&x,&y);

    //     for(int l=x;l<=k;l+=x)
    //     {
    //         count+=1;
    //     }
        
    }

    printf("Case %d: %d\n",i,count);



    }

    



    return 0;
}