#include<bits/stdc++.h>
using namespace std;
int main()
{

    int t;
    cin>>t;

    for(int i=1;i<=t;i++)
    {
        int n,k;
        cin>>n>>k;
        for(int )
    }



    return 0;
}